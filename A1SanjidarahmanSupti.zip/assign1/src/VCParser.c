#include "VCParser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef VCHELPERS_H
#define VCHELPERS_H

#include <stddef.h>

char* my_strdup(const char* str);
char* my_strndup(const char* str, size_t n);

#endif


VCardErrorCode createCard(char* fileName, Card** newCardObject) {
    if (fileName == NULL || newCardObject == NULL) {
        return INV_FILE;
    }

    FILE* file = fopen(fileName, "r");
    if (file == NULL) {
        *newCardObject = NULL;
        return INV_FILE;
    }

    Card* card = malloc(sizeof(Card));
    if (card == NULL) {
        fclose(file);
        *newCardObject = NULL;
        return OTHER_ERROR;
    }

    card->fn = NULL;
    card->optionalProperties = initializeList(&propertyToString, &deleteProperty, &compareProperties);
    card->birthday = NULL;
    card->anniversary = NULL;

    char line[1024];
    char prevLine[1024] = "";
    int foundBegin = 0, foundVersion = 0, foundEnd = 0;
    while (fgets(line, sizeof(line), file) != NULL) {
        size_t len = strlen(line);
    
        if (len > 1 && !(line[len - 2] == '\r' && line[len - 1] == '\n')) {
            fclose(file);
            deleteCard(card);
            *newCardObject = NULL;
            return INV_CARD;
        }
    
        line[len - 2] = '\0';

        if (line[0] == ' ' || line[0] == '\t') {
            if (card->fn != NULL && card->fn->values != NULL && card->fn->values->tail != NULL) {
                char* lastValue = (char*)card->fn->values->tail->data;
                size_t newSize = strlen(lastValue) + strlen(line + 1) + 1;
                char* newValue = realloc(lastValue, newSize);
                if (newValue) {
                    strcat(newValue, line + 1);  
                    card->fn->values->tail->data = newValue;
                }
            }
            continue; 
        } else {
            strcpy(prevLine, line);  
        }

        char* currentLine = prevLine;

        if (strncmp(currentLine, "BEGIN:VCARD", 11) == 0) {
            foundBegin = 1;
            continue;
        }

        if (strncmp(currentLine, "VERSION:", 8) == 0) {
            if (strcmp(currentLine + 8, "4.0") != 0) {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return INV_CARD;
            }
            foundVersion = 1;
            continue;
        }

        if (strncmp(currentLine, "FN:", 3) == 0) {

            if (card->fn != NULL) {
                deleteProperty(card->fn);
            }

            card->fn = malloc(sizeof(Property));
            if (!card->fn) {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            card->fn->name = my_strdup("FN");
            card->fn->group = my_strdup("");
            card->fn->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            card->fn->values = initializeList(&valueToString, &deleteValue, &compareValues);

            char* value = my_strdup(currentLine + 3);
            insertBack(card->fn->values, value);
        }

        else if (strncmp(currentLine, "N:", 2) == 0) {

            Property* nameProp = malloc(sizeof(Property));
            if (!nameProp) {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            nameProp->name = my_strdup("N");
            nameProp->group = my_strdup("");
            nameProp->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            nameProp->values = initializeList(&valueToString, &deleteValue, &compareValues);

            char* token = strtok(currentLine + 2, ";");
            int count = 0;
            while (token || count < 5) { 
                insertBack(nameProp->values, my_strdup(token ? token : ""));
                token = strtok(NULL, ";");
                count++;
            }
            insertBack(card->optionalProperties, nameProp);
        }

        else if (strncmp(line, "BDAY", 4) == 0 || strncmp(line, "ANNIVERSARY", 11) == 0) {
            DateTime** target = (line[0] == 'B') ? &(card->birthday) : &(card->anniversary);
        
            if (*target) {
                deleteDate(*target);
            }
        
            *target = malloc(sizeof(DateTime));
            if (!*target) {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }
            memset(*target, 0, sizeof(DateTime));
        
            char* colonPos = strchr(line, ':');
            char* semicolonPos = strchr(line, ';');
        
            if (!colonPos) {  
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return INV_PROP;
            }
        
            if (semicolonPos && semicolonPos < colonPos) {
                
                char* params = my_strndup(semicolonPos + 1, colonPos - semicolonPos - 1);
                if (strstr(params, "VALUE=text")) {
                    
                    (*target)->isText = true;
                    (*target)->text = my_strdup(colonPos + 1);
                    (*target)->date = my_strdup("");
                    (*target)->time = my_strdup("");
                    free(params);
                    continue;
                }
                free(params);
                
            } else {
               
                char* value = my_strdup(colonPos + 1);
        
                if (value[0] == 'T') {  
                    (*target)->date = my_strdup("");  
                    (*target)->time = my_strdup(value + 1);
                } else if (strchr(value, 'T')) {
                    
                    char* timePart = strchr(value, 'T');
                    *timePart = '\0';  
                    (*target)->date = my_strdup(value);
                    (*target)->time = my_strdup(timePart + 1);
                } else {
                    (*target)->date = my_strdup(value);
                    (*target)->time = my_strdup("");
                }
                if ((*target)->time && (*target)->time[strlen((*target)->time) - 1] == 'Z') {
                    (*target)->UTC = true;
                    (*target)->time[strlen((*target)->time) - 1] = '\0'; 
                } else {
                    (*target)->UTC = false;
                }
        
                (*target)->isText = false;
                free(value);
            }
        }
        
        else if (strncmp(currentLine, "END:VCARD", 9) == 0) {
            foundEnd = 1;
            
            break;
        }

        else {
            char* colonPos = strchr(line, ':');
if (!colonPos || colonPos == line) {  
    fclose(file);
    deleteCard(card);
    *newCardObject = NULL;
    return INV_PROP;
}
        
char* semicolonPos = strchr(line, ';');
char* dotPos = strchr(line, '.');
char* propertyName;
char* groupName = my_strdup("");  
char* parameters = NULL;

if (dotPos && dotPos < colonPos) {
    groupName = my_strndup(line, dotPos - line);
    propertyName = my_strndup(dotPos + 1, (semicolonPos && semicolonPos < colonPos) ? (semicolonPos - dotPos - 1) : (colonPos - dotPos - 1));
} else {
    propertyName = my_strndup(line, (semicolonPos && semicolonPos < colonPos) ? (semicolonPos - line) : (colonPos - line));
}

if (semicolonPos && semicolonPos < colonPos) {
    if (!strchr(semicolonPos + 1, '=')) {  
        free(propertyName);
        free(groupName);
        fclose(file);
        deleteCard(card);
        *newCardObject = NULL;
        return INV_PROP;
    }
    parameters = my_strndup(semicolonPos + 1, colonPos - semicolonPos - 1);
}
        
            char* propertyValue = my_strdup(colonPos + 1);


if (strchr(propertyValue, ';')) {
    for (char* p = propertyValue; *p; p++) {
        if (*p == ';') *p = ',';  
    }
}

        
            Property* property = malloc(sizeof(Property));
            if (!property) {
                free(propertyName);
                free(propertyValue);
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }
        
            property->name = propertyName;
            property->group = groupName;
            property->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            property->values = initializeList(&valueToString, &deleteValue, &compareValues);
        
            if (parameters) {
                char* paramToken = strtok(parameters, ";");
                while (paramToken) {
                    Parameter* param = malloc(sizeof(Parameter));
                    if (!param) {
                        free(parameters);
                        fclose(file);
                        deleteCard(card);
                        *newCardObject = NULL;
                        return OTHER_ERROR;
                    }
                    char* equalPos = strchr(paramToken, '=');
                    if (equalPos) {
                        *equalPos = '\0';
                        param->name = my_strdup(paramToken);
                        param->value = my_strdup(equalPos + 1);
            
                        if (param->value[0] == '"' && param->value[strlen(param->value) - 1] == '"') {
                            memmove(param->value, param->value + 1, strlen(param->value));  
                            param->value[strlen(param->value) - 1] = '\0';  
                        }
                    } else {
                        param->name = my_strdup(paramToken);
                        param->value = my_strdup("");
                    }
                    insertBack(property->parameters, param);
                    paramToken = strtok(NULL, ";");
                }
                free(parameters);
            }
        
            insertBack(property->values, propertyValue);
            insertBack(card->optionalProperties, property);
        }
        
    }

    fclose(file);

    if (!foundBegin || !foundVersion || card->fn == NULL || !foundEnd) {
        deleteCard(card);
        *newCardObject = NULL;
        return INV_CARD;
    }

    *newCardObject = card;
    return OK;
}


char* cardToString(const Card* obj) {
    if (obj == NULL) {
        return my_strdup("Invalid Card Object");
    }

    size_t bufferSize = 500;
    char* result = malloc(bufferSize);
    if (!result) return NULL;

    if (obj->anniversary) {
        char* annStr = dateToString(obj->anniversary);
        size_t newSize = strlen(result) + strlen(annStr) + 20;
        char* temp = realloc(result, newSize);
        if (temp) {
            result = temp;
            strcat(result, "Anniversary: ");
            strcat(result, annStr);
            strcat(result, "\n");
        }
        free(annStr);
    }
    

    if (obj->fn && obj->fn->values && obj->fn->values->head && obj->fn->values->head->data) {
        snprintf(result, bufferSize, "%s\n", (char*)obj->fn->values->head->data);
    } else {
        snprintf(result, bufferSize, "No FN Property\n");
    }

    ListIterator iter = createIterator(obj->optionalProperties);
    Property* prop;
    while ((prop = nextElement(&iter)) != NULL) {
        char* propStr = propertyToString(prop);
        size_t newSize = strlen(result) + strlen(propStr) + 64;
        char* temp = realloc(result, newSize);
        if (temp) {
            result = temp;
            strcat(result, propStr);
            strcat(result, "\n");
        }
        free(propStr);
    }
    return result;
}


void deleteCard(Card* obj) {
    if (obj == NULL) {
        return;
    }

    if (obj->fn != NULL) {
        deleteProperty(obj->fn);
        obj->fn = NULL;
    }

    if (obj->optionalProperties != NULL) {
        clearList(obj->optionalProperties);  
        free(obj->optionalProperties);
        obj->optionalProperties = NULL;
    }

    if (obj->birthday != NULL) {
        deleteDate(obj->birthday);
        obj->birthday = NULL;
    }

    if (obj->anniversary != NULL) {
        deleteDate(obj->anniversary);
        obj->anniversary = NULL;
    }

    free(obj);
    obj = NULL;
}

char* errorToString(VCardErrorCode err) {
    char* result;
    switch (err) {
        case OK: result = my_strdup("OK"); break;
        case INV_FILE: result = my_strdup("INV_FILE"); break;
        case INV_CARD: result = my_strdup("INV_CARD"); break;
        case INV_PROP: result = my_strdup("INV_PROP"); break;
        case INV_DT: result = my_strdup("INV_DT"); break;
        case WRITE_ERROR: result = my_strdup("WRITE_ERROR"); break;
        case OTHER_ERROR: result = my_strdup("OTHER_ERROR"); break;
        default: result = my_strdup("Unknown_Error"); break;
    }
    return result;
}

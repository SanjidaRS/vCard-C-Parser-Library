#ifndef _VCHELPERS_H_
#define _VCHELPERS_H_

#include <stdlib.h>
#include <string.h>

#include "VCParser.h"

#ifndef MY_STRDUP_DEFINED
#define MY_STRDUP_DEFINED

char* my_strdup(const char* str) {
    if (str == NULL) return NULL;
    size_t len = strlen(str) + 1;
    char* copy = malloc(len);
    if (copy) {
        strcpy(copy, str);
    }
    return copy;
}
#endif

#ifndef MY_STRNDUP_DEFINED
#define MY_STRNDUP_DEFINED

char* my_strndup(const char* str, size_t n) {
    if (str == NULL) return NULL;

    size_t len = strlen(str);
    if (len > n) len = n;  

    char* copy = malloc(len + 1);
    if (copy) {
        strncpy(copy, str, len);
        copy[len] = '\0';  
    }
    return copy;
}
#endif

void parseDateTime(DateTime* dateTime, char* value) {
    if (!dateTime || !value) return;
    
    if (strchr(value, 'T')) {
        dateTime->UTC = false;
        sscanf(value, "%8sT%6s", dateTime->date, dateTime->time);
    } else {
        dateTime->UTC = false;
        strcpy(dateTime->date, value);
        strcpy(dateTime->time, "");
    }
}

void deleteProperty(void* toBeDeleted) {
    if (!toBeDeleted) return;
    Property* property = (Property*)toBeDeleted;

    if (property->name) {
        free(property->name);
        property->name = NULL;
    }

    if (property->group) {
        free(property->group);
        property->group = NULL;
    }

    if (property->parameters) {
        ListIterator paramIter = createIterator(property->parameters);
        Parameter* param;
        while ((param = nextElement(&paramIter))) {
            free(param->name);
            free(param->value);
            free(param);
        }
        freeList(property->parameters);
        property->parameters = NULL;
    }

    if (property->values) {
        freeList(property->values);
        property->values = NULL;
    }

    free(property);
}

int compareProperties(const void* first, const void* second) {
    if (!first || !second) return 0;
    return strcmp(((Property*)first)->name, ((Property*)second)->name);
}

char* propertyToString(void* prop) {
    if (!prop) return my_strdup("Invalid Property");
    Property* property = (Property*)prop;
    size_t bufferSize = 256;
    char* result = malloc(bufferSize);
    if (!result) return NULL;

    snprintf(result, bufferSize, "Property: %s\nGroup: %s\n", property->name, property->group);
    strcat(result, "Parameters:\n");

    ListIterator paramIter = createIterator(property->parameters);
    Parameter* param;
    while ((param = nextElement(&paramIter))) {
        if (!param) continue;
        size_t newSize = strlen(result) + strlen(param->name) + strlen(param->value) + 32;
        char* temp = realloc(result, newSize);
        if (!temp) { free(result); return NULL; }
        result = temp;
        strcat(result, "- ");
        strcat(result, param->name);
        strcat(result, "=");
        strcat(result, param->value);
        strcat(result, "\n");
    }

    strcat(result, "Values:\n");
    ListIterator valueIter = createIterator(property->values);
    char* value;
    while ((value = nextElement(&valueIter))) {
        if (!value) continue;
        size_t newSize = strlen(result) + strlen(value) + 32;
        char* temp = realloc(result, newSize);
        if (!temp) { free(result); return NULL; }
        result = temp;
        strcat(result, "- ");
        strcat(result, value);
        strcat(result, "\n");
    }

    return result;
}

void deleteParameter(void* toBeDeleted) {
    if (!toBeDeleted) return;
    Parameter* param = (Parameter*)toBeDeleted;
    free(param->name);
    free(param->value);
    free(param);
}

int compareParameters(const void* first, const void* second) {
    if (!first || !second) return 0;
    return strcmp(((Parameter*)first)->name, ((Parameter*)second)->name);
}

char* parameterToString(void* param) {
    if (!param) return my_strdup("Invalid Parameter");
    Parameter* parameter = (Parameter*)param;
    size_t bufferSize = strlen(parameter->name) + strlen(parameter->value) + 32;
    char* result = malloc(bufferSize);
    snprintf(result, bufferSize, "Parameter: %s = %s", parameter->name, parameter->value);
    return result;
}

void deleteValue(void* toBeDeleted) {
    if (!toBeDeleted) return;
    free((char*)toBeDeleted);
}

int compareValues(const void* first, const void* second) {
    if (!first && !second) return 0;
    if (!first) return -1;
    if (!second) return 1;
    return strcmp((const char*)first, (const char*)second);
}

char* valueToString(void* val) {
    if (!val) return my_strdup("Invalid Value");
    return my_strdup((char*)val);
}

void deleteDate(void* toBeDeleted) {
    if (!toBeDeleted) return;
    DateTime* date = (DateTime*)toBeDeleted;

    if (date->date) {
        free(date->date);
        date->date = NULL;
    }

    if (date->time) {
        free(date->time);
        date->time = NULL;
    }

    if (date->text) {
        free(date->text);
        date->text = NULL;
    }

    free(date);
}

int compareDates(const void* first __attribute__((unused)), const void* second __attribute__((unused))) {
    return 0;
}

char* dateToString(void* date) {
    if (!date) return my_strdup("Invalid Date");
    DateTime* dt = (DateTime*)date;
    size_t bufferSize = (dt->date ? strlen(dt->date) : 0) + 
                        (dt->time ? strlen(dt->time) : 0) + 
                        (dt->text ? strlen(dt->text) : 0) + 64;
    char* result = malloc(bufferSize);
    snprintf(result, bufferSize, "Date: %s, Time: %s, Text: %s, UTC: %s",
             dt->date ? dt->date : "N/A",
             dt->time ? dt->time : "N/A",
             dt->text ? dt->text : "N/A",
             dt->UTC ? "Yes" : "No");
    return result;
}

#endif  




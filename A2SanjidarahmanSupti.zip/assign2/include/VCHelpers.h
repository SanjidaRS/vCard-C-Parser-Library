#ifndef _VCHELPERS_H_
#define _VCHELPERS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "VCParser.h"
#include "LinkedListAPI.h"

char *my_strdup(const char *str);
char *my_strndup(const char *str, size_t n);

bool isValidProperty(const char *name);
bool isValidDateTime(const DateTime *dt);

void writeDateTime(FILE *file, const char *propName, const DateTime *dt);
void writeProperty(FILE *file, Property *prop);
void writeOptionalProperties(FILE *file, List *properties);

void deleteProperty(void *toBeDeleted);
int compareProperties(const void *first, const void *second);
char *propertyToString(void *prop);

void deleteParameter(void *toBeDeleted);
int compareParameters(const void *first, const void *second);
char *parameterToString(void *param);

void deleteValue(void *toBeDeleted);
int compareValues(const void *first, const void *second);
char *valueToString(void *val);

#endif

#include "VCParser.h"
#include "LinkedListAPI.h"
#include "VCHelpers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool isValidProperty(const char *name);
bool isValidDateTime(const DateTime *dt);
void writeDateTime(FILE *file, const char *propName, const DateTime *dt);
void writeProperty(FILE *file, Property *prop);
void writeOptionalProperties(FILE *file, List *properties);
void deleteDateTime(void *toBeDeleted);

VCardErrorCode createCard(char *fileName, Card **newCardObject)
{
    if (fileName == NULL || newCardObject == NULL)
    {
        return INV_FILE;
    }

    FILE *file = fopen(fileName, "r");
    if (file == NULL)
    {
        *newCardObject = NULL;
        return INV_FILE;
    }

    Card *card = malloc(sizeof(Card));
    if (card == NULL)
    {
        fclose(file);
        *newCardObject = NULL;
        return OTHER_ERROR;
    }

    card->fn = NULL;
    card->optionalProperties = initializeList(&propertyToString, &deleteProperty, &compareProperties);
    card->birthday = NULL;
    card->anniversary = NULL;

    char line[1024];
    char prevLine[1024] = "";
    int foundBegin = 0, foundVersion = 0, foundEnd = 0;
    while (fgets(line, sizeof(line), file) != NULL)
    {
        size_t len = strlen(line);

        if (len > 1 && !(line[len - 2] == '\r' && line[len - 1] == '\n'))
        {
            fclose(file);
            deleteCard(card);
            *newCardObject = NULL;
            return INV_CARD;
        }

        line[len - 2] = '\0';

        if (line[0] == ' ' || line[0] == '\t')
        {
            if (card->fn != NULL && card->fn->values != NULL && card->fn->values->tail != NULL)
            {
                char *lastValue = (char *)card->fn->values->tail->data;
                size_t newSize = strlen(lastValue) + strlen(line + 1) + 1;
                char *newValue = realloc(lastValue, newSize);
                if (newValue)
                {
                    strcat(newValue, line + 1);
                    card->fn->values->tail->data = newValue;
                }
            }
            continue;
        }
        else
        {
            strcpy(prevLine, line);
        }

        char *currentLine = prevLine;

        if (strncmp(currentLine, "BEGIN:VCARD", 11) == 0)
        {
            foundBegin = 1;
            continue;
        }

        if (strncmp(currentLine, "VERSION:", 8) == 0)
        {
            if (strcmp(currentLine + 8, "4.0") != 0)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return INV_CARD;
            }
            foundVersion = 1;
            continue;
        }

        if (strncmp(currentLine, "FN:", 3) == 0)
        {

            if (card->fn != NULL)
            {
                deleteProperty(card->fn);
            }

            card->fn = malloc(sizeof(Property));
            if (!card->fn)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            card->fn->name = my_strdup("FN");
            card->fn->group = my_strdup("");
            card->fn->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            card->fn->values = initializeList(&valueToString, &deleteValue, &compareValues);

            char *value = my_strdup(currentLine + 3);
            insertBack(card->fn->values, value);
        }
        else if (strncmp(currentLine, "ADR:", 4) == 0)
        {
            Property *adrProp = malloc(sizeof(Property));
            if (!adrProp)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            adrProp->name = my_strdup("ADR");
            adrProp->group = my_strdup("");
            adrProp->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            adrProp->values = initializeList(&valueToString, &deleteValue, &compareValues);
            char *token = strtok(currentLine + 4, ";");
            int count = 0;
            while (token || count < 7)
            {
                insertBack(adrProp->values, my_strdup(token ? token : ""));
                token = strtok(NULL, ";");
                count++;
            }

            insertBack(card->optionalProperties, adrProp);
        }

        else if (strncmp(currentLine, "N:", 2) == 0)
        {

            Property *nameProp = malloc(sizeof(Property));
            if (!nameProp)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            nameProp->name = my_strdup("N");
            nameProp->group = my_strdup("");
            nameProp->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            nameProp->values = initializeList(&valueToString, &deleteValue, &compareValues);

            char *token = strtok(currentLine + 2, ";");
            int count = 0;
            while (token || count < 5)
            {
                insertBack(nameProp->values, my_strdup(token ? token : ""));
                token = strtok(NULL, ";");
                count++;
            }
            insertBack(card->optionalProperties, nameProp);
        }

        else if (strncmp(line, "BDAY", 4) == 0 || strncmp(line, "ANNIVERSARY", 11) == 0)
        {
            DateTime **target = (line[0] == 'B') ? &(card->birthday) : &(card->anniversary);

            if (*target)
            {
                deleteDate(*target);
            }

            *target = malloc(sizeof(DateTime));
            if (!*target)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }
            memset(*target, 0, sizeof(DateTime));

            char *colonPos = strchr(line, ':');
            char *semicolonPos = strchr(line, ';');

            if (!colonPos)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return INV_PROP;
            }

            if (semicolonPos && semicolonPos < colonPos)
            {
                char *params = my_strndup(semicolonPos + 1, colonPos - semicolonPos - 1);
                if (strstr(params, "VALUE=text"))
                {
                    (*target)->isText = true;
                    (*target)->text = my_strdup(colonPos + 1);
                    (*target)->date = my_strdup("");
                    (*target)->time = my_strdup("");
                    free(params);
                    continue;
                }
                free(params);
            }

            else
            {
                char *value = my_strdup(colonPos + 1);

                if (value[0] == 'T')
                {
                    (*target)->date = my_strdup("");
                    (*target)->time = my_strdup(value + 1);
                }
                else if (strchr(value, 'T'))
                {

                    char *timePart = strchr(value, 'T');
                    *timePart = '\0';
                    (*target)->date = my_strdup(value);
                    (*target)->time = my_strdup(timePart + 1);
                }
                else
                {
                    (*target)->date = my_strdup(value);
                    (*target)->time = my_strdup("");
                }

                if ((*target)->time && (*target)->time[strlen((*target)->time) - 1] == 'Z')
                {
                    (*target)->UTC = true;
                    (*target)->time[strlen((*target)->time) - 1] = '\0';
                }
                else
                {
                    (*target)->UTC = false;
                }

                (*target)->isText = false;
                free(value);
            }
        }

        else if (strncmp(currentLine, "END:VCARD", 9) == 0)
        {
            foundEnd = 1;

            break;
        }

        else
        {
            char *colonPos = strchr(line, ':');
            if (!colonPos || colonPos == line)
            {
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return INV_PROP;
            }

            char *semicolonPos = strchr(line, ';');
            char *dotPos = strchr(line, '.');
            char *propertyName;
            char *groupName = my_strdup("");
            char *parameters = NULL;

            if (dotPos && dotPos < colonPos)
            {
                groupName = my_strndup(line, dotPos - line);
                propertyName = my_strndup(dotPos + 1, (semicolonPos && semicolonPos < colonPos) ? (semicolonPos - dotPos - 1) : (colonPos - dotPos - 1));
            }
            else
            {
                propertyName = my_strndup(line, (semicolonPos && semicolonPos < colonPos) ? (semicolonPos - line) : (colonPos - line));
            }

            if (semicolonPos && semicolonPos < colonPos)
            {
                if (!strchr(semicolonPos + 1, '='))
                {
                    free(propertyName);
                    free(groupName);
                    fclose(file);
                    deleteCard(card);
                    *newCardObject = NULL;
                    return INV_PROP;
                }
                parameters = my_strndup(semicolonPos + 1, colonPos - semicolonPos - 1);
            }

            char *propertyValue = my_strdup(colonPos + 1);

            if (strchr(propertyValue, ';'))
            {
                for (char *p = propertyValue; *p; p++)
                {
                    if (*p == ';')
                        *p = ',';
                }
            }

            Property *property = malloc(sizeof(Property));
            if (!property)
            {
                free(propertyName);
                free(propertyValue);
                fclose(file);
                deleteCard(card);
                *newCardObject = NULL;
                return OTHER_ERROR;
            }

            property->name = propertyName;
            property->group = groupName;
            property->parameters = initializeList(&parameterToString, &deleteParameter, &compareParameters);
            property->values = initializeList(&valueToString, &deleteValue, &compareValues);

            if (parameters)
            {
                char *paramToken = strtok(parameters, ";");
                while (paramToken)
                {
                    Parameter *param = malloc(sizeof(Parameter));
                    if (!param)
                    {
                        free(parameters);
                        fclose(file);
                        deleteCard(card);
                        *newCardObject = NULL;
                        return OTHER_ERROR;
                    }
                    char *equalPos = strchr(paramToken, '=');
                    if (equalPos)
                    {
                        *equalPos = '\0';
                        param->name = my_strdup(paramToken);
                        param->value = my_strdup(equalPos + 1);

                        if (param->value[0] == '"' && param->value[strlen(param->value) - 1] == '"')
                        {
                            memmove(param->value, param->value + 1, strlen(param->value));
                            param->value[strlen(param->value) - 1] = '\0';
                        }
                    }
                    else
                    {
                        param->name = my_strdup(paramToken);
                        param->value = my_strdup("");
                    }
                    insertBack(property->parameters, param);
                    paramToken = strtok(NULL, ";");
                }
                free(parameters);
            }

            insertBack(property->values, propertyValue);
            insertBack(card->optionalProperties, property);
        }
    }

    fclose(file);

    if (!foundBegin || !foundVersion || card->fn == NULL || !foundEnd)
    {
        deleteCard(card);
        *newCardObject = NULL;
        return INV_CARD;
    }

    *newCardObject = card;
    return OK;
}

VCardErrorCode writeCard(const char *fileName, const Card *obj)
{
    if (fileName == NULL || obj == NULL)
    {
        return WRITE_ERROR;
    }

    FILE *file = fopen(fileName, "w");
    if (file == NULL)
    {
        return WRITE_ERROR;
    }

    fprintf(file, "BEGIN:VCARD\r\n");
    fprintf(file, "VERSION:4.0\r\n");

    if (obj->fn != NULL && obj->fn->values != NULL && getLength(obj->fn->values) > 0)
    {
        fprintf(file, "FN:");
        ListIterator iter = createIterator(obj->fn->values);
        char *value;
        bool firstValue = true;
        while ((value = nextElement(&iter)) != NULL)
        {
            if (!firstValue)
            {
                fprintf(file, ";");
            }
            fprintf(file, "%s", value);
            firstValue = false;
        }
        fprintf(file, "\r\n");
    }
    else
    {
        fclose(file);
        return WRITE_ERROR;
    }

    ListIterator propIter = createIterator(obj->optionalProperties);
    Property *prop;
    while ((prop = nextElement(&propIter)) != NULL)
    {
        if (prop->name == NULL || prop->values == NULL || getLength(prop->values) == 0)
        {
            continue;
        }

        fprintf(file, "%s", prop->name);

        ListIterator paramIter = createIterator(prop->parameters);
        Parameter *param;
        while ((param = nextElement(&paramIter)) != NULL)
        {
            fprintf(file, ";%s=%s", param->name, param->value);
        }
        fprintf(file, ":");

        ListIterator valueIter = createIterator(prop->values);
        char *value;
        bool firstValue = true;
        while ((value = nextElement(&valueIter)) != NULL)
        {
            if (!firstValue)
            {
                fprintf(file, ";");
            }
            fprintf(file, "%s", value);
            firstValue = false;
        }
        fprintf(file, "\r\n");
    }
    if (obj->birthday != NULL)
    {
        if (obj->birthday->isText)
        {
            fprintf(file, "BDAY;VALUE=text:%s\r\n", obj->birthday->text);
        }
        else if (strlen(obj->birthday->date) == 0 && strlen(obj->birthday->time) > 0)
        {

            fprintf(file, "BDAY:T%s", obj->birthday->time);
            if (obj->birthday->UTC)
            {
                fprintf(file, "Z");
            }
            fprintf(file, "\r\n");
        }
        else if (strlen(obj->birthday->date) > 0 && strlen(obj->birthday->time) == 0)
        {

            fprintf(file, "BDAY:%s\r\n", obj->birthday->date);
        }
        else if (strlen(obj->birthday->date) > 0 && strlen(obj->birthday->time) > 0)
        {

            fprintf(file, "BDAY:%sT%s", obj->birthday->date, obj->birthday->time);
            if (obj->birthday->UTC)
            {
                fprintf(file, "Z");
            }
            fprintf(file, "\r\n");
        }
    }

    if (obj->anniversary != NULL)
    {
        fprintf(file, "ANNIVERSARY");
        if (obj->anniversary->isText)
        {
            fprintf(file, ";VALUE=text:%s\r\n", obj->anniversary->text);
        }
        else if (strlen(obj->anniversary->date) > 0 && strlen(obj->anniversary->time) == 0)
        {
            fprintf(file, ":%s\r\n", obj->anniversary->date);
        }
        else if (strlen(obj->anniversary->date) == 0 && strlen(obj->anniversary->time) > 0)
        {
            fprintf(file, ":T%s", obj->anniversary->time);
            if (obj->anniversary->UTC)
            {
                fprintf(file, "Z");
            }
            fprintf(file, "\r\n");
        }
        else
        {
            fprintf(file, ":%sT%s", obj->anniversary->date, obj->anniversary->time);
            if (obj->anniversary->UTC)
            {
                fprintf(file, "Z");
            }
            fprintf(file, "\r\n");
        }
    }

    fprintf(file, "END:VCARD\r\n");
    fclose(file);
    return OK;
}

VCardErrorCode validateCard(const Card *obj)
{
    if (!obj)
        return INV_CARD;
    if (!obj->fn || !obj->fn->values || getLength(obj->fn->values) == 0)
    {
        return INV_CARD;
    }
    ListIterator fnIter = createIterator(obj->fn->values);
    char *fnValue;
    bool validFn = false;
    while ((fnValue = nextElement(&fnIter)))
    {
        if (fnValue && strlen(fnValue) > 0)
        {
            validFn = true;
            break;
        }
    }
    if (!validFn)
    {
        return INV_CARD;
    }
    if (!obj->optionalProperties)
    {
        return INV_CARD;
    }

    bool hasBDAY = false, hasANNIVERSARY = false;

    ListIterator propIter = createIterator(obj->optionalProperties);
    Property *prop;
    while ((prop = nextElement(&propIter)))
    {
        if (!prop->name || getLength(prop->values) == 0)
        {
            return INV_PROP;
        }
        if (strcmp(prop->name, "VERSION") == 0)
        {
            return INV_CARD;
        }
        if (!isValidProperty(prop->name))
        {
            return INV_PROP;
        }
        if (strcmp(prop->name, "BDAY") == 0)
            hasBDAY = true;
        if (strcmp(prop->name, "ANNIVERSARY") == 0)
            hasANNIVERSARY = true;
    }
    if (hasBDAY || hasANNIVERSARY)
    {
        return INV_DT;
    }
    if (obj->birthday != NULL)
    {
        if (!isValidDateTime(obj->birthday))
        {
            return INV_DT;
        }
    }
    if (obj->anniversary != NULL)
    {
        if (!isValidDateTime(obj->anniversary))
        {
            return INV_DT;
        }
    }

    return OK;
}

void deleteCard(Card *obj)
{
    if (!obj)
        return;

    if (obj->fn)
    {
        deleteProperty(obj->fn);
    }
    if (obj->optionalProperties)
    {
        clearList(obj->optionalProperties);
        freeList(obj->optionalProperties);
    }

    if (obj->birthday)
    {
        deleteDateTime(obj->birthday);
    }
    if (obj->anniversary)
    {
        deleteDateTime(obj->anniversary);
    }

    free(obj);
}

char *errorToString(VCardErrorCode err)
{
    switch (err)
    {
    case OK:
        return strdup("OK");
    case INV_FILE:
        return strdup("INV_FILE");
    case INV_CARD:
        return strdup("INV_CARD");
    case INV_PROP:
        return strdup("INV_PROP");
    case INV_DT:
        return strdup("INV_DT");
    case WRITE_ERROR:
        return strdup("WRITE_ERROR");
    case OTHER_ERROR:
        return strdup("OTHER_ERROR");
    default:
        return strdup("UNKNOWN_ERROR");
    }
}

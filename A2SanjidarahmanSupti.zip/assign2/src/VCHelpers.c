#include "VCHelpers.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

char *my_strdup(const char *str)
{
    if (str == NULL)
        return NULL;
    size_t len = strlen(str) + 1;
    char *copy = malloc(len);
    if (!copy)
        return NULL;

    strcpy(copy, str);
    return copy;
}

char *my_strndup(const char *str, size_t n)
{
    if (str == NULL)
        return NULL;

    size_t len = strlen(str);
    if (len > n)
        len = n;

    char *copy = malloc(len + 1);
    if (!copy)
        return NULL;

    strncpy(copy, str, len);
    copy[len] = '\0';
    return copy;
}

bool isValidProperty(const char *name)
{
    if (name == NULL)
        return false;

    const char *validProperties[] = {
        "FN", "N", "BDAY", "ANNIVERSARY", "ORG", "TITLE", "TEL", "EMAIL", "ADR"};

    for (int i = 0; i < sizeof(validProperties) / sizeof(validProperties[0]); i++)
    {
        if (strcmp(name, validProperties[i]) == 0)
        {
            return true;
        }
    }
    return false;
}

bool isValidDateTime(const DateTime *dt)
{
    if (!dt)
        return false;

    if (dt->isText)
    {
        if (strlen(dt->text) == 0)
        {
            return false;
        }
        if (strlen(dt->date) > 0 || strlen(dt->time) > 0 || dt->UTC)
        {
            return false;
        }
        return true;
    }

    if (strlen(dt->text) > 0)
    {
        return false;
    }

    if (strlen(dt->date) > 0 && strlen(dt->date) != 8)
    {
        return false;
    }

    if (strlen(dt->time) > 0 && strlen(dt->time) != 6)
    {
        return false;
    }

    return true;
}

void writeDateTime(FILE *file, const char *label, const DateTime *dt)
{
    if (!file || !label || !dt)
        return;

    fprintf(file, "%s:", label);

    if (dt->isText)
    {
        fprintf(file, "%s\r\n", dt->text);
    }
    else
    {
        if (strlen(dt->date) > 0 && strlen(dt->time) == 0)
        {
            fprintf(file, "%s\r\n", dt->date);
        }
        else if (strlen(dt->date) == 0 && strlen(dt->time) > 0)
        {
            fprintf(file, "--T%s", dt->time);
            if (dt->UTC)
                fprintf(file, "Z");
            fprintf(file, "\r\n");
        }
        else if (strlen(dt->date) > 0 && strlen(dt->time) > 0)
        {
            fprintf(file, "%sT%s", dt->date, dt->time);
            if (dt->UTC)
                fprintf(file, "Z");
            fprintf(file, "\r\n");
        }
    }
}

void writeProperty(FILE *file, Property *prop)
{
    if (!file || !prop || !prop->name || !prop->values || prop->values->head == NULL)
        return;

    fprintf(file, "%s:", prop->name);

    ListIterator iter = createIterator(prop->values);
    char *value;
    bool first = true;
    while ((value = nextElement(&iter)))
    {
        if (!first)
            fprintf(file, ";");
        fprintf(file, "%s", value);
        first = false;
    }
    fprintf(file, "\r\n");
}

void writeOptionalProperties(FILE *file, List *properties)
{
    if (!file || !properties || getLength(properties) == 0)
        return;

    ListIterator iter = createIterator(properties);
    Property *prop;
    while ((prop = nextElement(&iter)))
    {
        if (!prop || !prop->name || !prop->values || prop->values->head == NULL)
            continue;

        fprintf(file, "%s:", prop->name);

        ListIterator valIter = createIterator(prop->values);
        char *val;
        bool first = true;
        while ((val = nextElement(&valIter)))
        {
            if (!first)
                fprintf(file, ";");
            fprintf(file, "%s", val);
            first = false;
        }

        fprintf(file, "\r\n");
    }
}

void deleteProperty(void *toBeDeleted)
{
    if (!toBeDeleted)
        return;

    Property *property = (Property *)toBeDeleted;

    free(property->name);
    free(property->group);

    if (property->parameters)
    {
        clearList(property->parameters);
        free(property->parameters);
    }

    if (property->values)
    {
        clearList(property->values);
        free(property->values);
    }

    free(property);
}

int compareProperties(const void *first, const void *second)
{
    if (!first || !second)
        return 0;
    return strcmp(((Property *)first)->name, ((Property *)second)->name);
}

char *propertyToString(void *prop)
{
    if (!prop)
        return my_strdup("Invalid Property");

    Property *property = (Property *)prop;
    size_t bufferSize = 256;
    char *result = malloc(bufferSize);
    if (!result)
        return NULL;

    snprintf(result, bufferSize, "Property: %s\nGroup: %s\n", property->name, property->group);
    strcat(result, "Parameters:\n");

    ListIterator paramIter = createIterator(property->parameters);
    Parameter *param;
    while ((param = nextElement(&paramIter)))
    {
        if (!param)
            continue;

        size_t newSize = strlen(result) + strlen(param->name) + strlen(param->value) + 32;
        char *temp = realloc(result, newSize);
        if (!temp)
        {
            free(result);
            return NULL;
        }
        result = temp;

        strcat(result, "- ");
        strcat(result, param->name);
        strcat(result, "=");
        strcat(result, param->value);
        strcat(result, "\n");
    }

    strcat(result, "Values:\n");
    ListIterator valueIter = createIterator(property->values);
    char *value;
    while ((value = nextElement(&valueIter)))
    {
        if (!value)
            continue;

        size_t newSize = strlen(result) + strlen(value) + 32;
        char *temp = realloc(result, newSize);
        if (!temp)
        {
            free(result);
            return NULL;
        }
        result = temp;

        strcat(result, "- ");
        strcat(result, value);
        strcat(result, "\n");
    }

    return result;
}

void deleteParameter(void *toBeDeleted)
{
    if (!toBeDeleted)
        return;

    Parameter *param = (Parameter *)toBeDeleted;

    if (param->name)
        free(param->name);
    if (param->value)
        free(param->value);

    free(param);
}

int compareParameters(const void *first, const void *second)
{
    if (!first || !second)
        return 0;
    return strcmp(((Parameter *)first)->name, ((Parameter *)second)->name);
}

char *parameterToString(void *param)
{
    if (!param)
        return my_strdup("Invalid Parameter");
    Parameter *parameter = (Parameter *)param;
    size_t bufferSize = strlen(parameter->name) + strlen(parameter->value) + 32;
    char *result = malloc(bufferSize);
    snprintf(result, bufferSize, "Parameter: %s = %s", parameter->name, parameter->value);
    return result;
}

void deleteValue(void *toBeDeleted)
{
    if (!toBeDeleted)
        return;
    free((char *)toBeDeleted);
}

int compareValues(const void *first, const void *second)
{
    if (!first && !second)
        return 0;
    if (!first)
        return -1;
    if (!second)
        return 1;
    return strcmp((const char *)first, (const char *)second);
}

char *valueToString(void *val)
{
    if (!val)
        return my_strdup("Invalid Value");

    char *result = my_strdup((char *)val);
    if (!result)
        return NULL;

    return result;
}

void deleteDateTime(void *toBeDeleted)
{
    if (!toBeDeleted)
        return;

    DateTime *dt = (DateTime *)toBeDeleted;

    if (dt->text)
    {
        free(dt->text);
        dt->text = NULL;
    }

    free(dt);
}
